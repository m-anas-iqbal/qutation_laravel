<script src="{{ my_asset('plugins/table/datatable/datatables.js') }}"></script>
<script src="{{ my_asset('plugins/table/datatable/button-ext/dataTables.buttons.min.js') }}"></script>
<script src="{{ my_asset('plugins/table/datatable/button-ext/jszip.min.js') }}"></script>
<script src="{{ my_asset('plugins/table/datatable/button-ext/buttons.html5.min.js') }}"></script>
<script src="{{ my_asset('plugins/table/datatable/button-ext/buttons.print.min.js') }}"></script>
